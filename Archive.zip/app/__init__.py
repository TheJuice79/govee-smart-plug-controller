# app/__init__.py
# This marks the app directory as a package.
# You can optionally define shared variables or expose key components here.

__version__ = "1.2.0"
